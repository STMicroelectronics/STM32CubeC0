**
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32C01x-03x devices support on EWARM.
  ************************************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************

  These packages contains the needed files to be installed in order to support STM32C01x-03x 
  devices by EWARM8 and laters.

  1. If you have already installed an STM32C01x-03x patch before, you can remove it by running 
      Uninstall_Patch.bat (run as administrator).
  
  2. Running the "EWARMv8_STM32C01x-03x_V1.0.exe" adds the following:
   ============================================================== 
   - Part Numbers with 32KB Flash size: STM32C011x6/STM32C031x6
   - Part Numbers with 16KB Flash size: STM32C011x4/STM32C031x4
   - Automatic STM32C0xx flash algorithm selection
   - STM32C011 and STM32C031 SVD files 


  How to use:
  ==========
  * Before installing the files mentioned above, you need to have EWARM v8.xx or later installed. 
  You can download EWARM from IAR web site @ www.iar.com

  * Run "EWARMv8_STM32C01x-03x_V1.0.exe" as administrator at EWARM install directory.
  EWARM Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \",





	



