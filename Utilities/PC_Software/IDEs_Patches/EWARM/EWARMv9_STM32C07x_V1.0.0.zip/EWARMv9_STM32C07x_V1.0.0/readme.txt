**
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32C07x devices support on EWARM.
  ************************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************

 Package general purpose:
  ======================================================================================================================	
    These packages contains the needed files to be installed in order to support STM32C07x devices by EWARM9 and laters.

    We inform you that this package is suitable for internal & external use.
	EWARMv9_STM32C07x_V1.0.0.exe has been digitally signed by STMicroelectronics.

  By running the "Install_Patch.bat" file (as an administrator), the following actions will be performed: : 
  ================================================================ 
     1. If you have previously installed an STM32 patch, it will be removed during the first run. 
     2. The following items will be added :
      
	  - Part Numbers with 128KB Flash size: STM32C071xB.
      - Part Numbers with 64KB Flash size: STM32C071x8.
      
	  - Automatic STM32C0xx flash algorithm selection
	  
     3. The following SVD files will be added: 
	  - STM32C071 SVD files v1r1. 


PS: That you can run EWARMv9_STM32C07x_V1.0.0.exe only if the uninstall is not needed.
	
  How to use:
  ==========
  * Before installing the files mentioned above, you need to have EWARM v9.xx or later installed. 
   
    You can download EWARM from IAR web site @ www.iar.com

  * Run "EWARMv9_STM32C07x_V1.0.0.exe" as administrator at EWARM install directory.
    EWARM Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \",

  SVD files ReleaseNotes:
  =======================
	=======================================================
	STM32C071_v0r1:     initial release
	=======================================================
	Doc ID: RM0490 - Rev 3.1c - 28 June 2023
	
	IPs Derived from IPxact (ipxact_RM0490_V3_STM32C0_Spider_1230908_1432):
	- Complete support for interrupts
	- Reducing warnings number by 100% (0 Errors and 0 Warnings)
	- Only missing TIM2 & USBSRAM
	
	=======================================================
	STM32C071_v1r0:     official release
	=======================================================
	Doc ID: RM0490 - Rev 3.1c - 28 June 2023
	
	Update version for official release 0.1 => 1.0
	
	#update license section#
	
	=======================================================
	STM32C071_v1r1:     update
	=======================================================
	Doc ID: RM0490 Rev 3.2
	
	update to be aligned with latest RM
	adding support for missing IPs (TIM2)
	complete support for interrupts
	0 ERRORS/0 WARNINGS


	



