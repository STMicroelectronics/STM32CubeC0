**
  *************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32C01x-3x devices support on EWARM.
  *************************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************

 Package general purpose:
  ======================================================================================================================	
  These packages contains the needed files to be installed in order to support STM32C01x-3x 
  devices by EWARM9 and laters.

  We inform you that this package is suitable for internal & external use.
  EWARMv8_STM32C01x-03x_V1.0.1.exe has been digitally signed by STMicroelectronics.

  
  By running the "Install_Patch.bat" file (as an administrator), the following actions will be performed: : 
  ================================================================ 
     1. If you have previously installed an STM32 patch, it will be removed during the first run. 
     2. The following items will be added :
	
    - Product line with 32KB Flash size: STM32C011x6/STM32C031x6
    - Product line with 16KB Flash size: STM32C011x4/STM32C031x4
	
    - Automatic STM32C0 Internal Flash algorithm selection.
  
    3. The following SVD files will be added:
    - STM32C031 & STM32C011 SVD file v1r2.
  
PS: When using external loader on EWARM, please unselect the verify from the debug menu.The verification is done by the flashloader.
    That you can run EWARMv8_STM32C01x-03x_V1.0.1.exe only if the uninstall is not needed.

 How to use:
 ==========
 * Before installing the files mentioned above, you need to have EWARM v9.20.1 or later installed. 
 
  You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv8_STM32C01x-03x_V1.0.1.exe" or using the "Install_Patch.bat" as administrator on EWARM install directory.
   Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \".
   Please change it manually if you have EWARM installed at a different location.   
	

 SVD files ReleaseNotes:
 =======================
        =======================================================
		STM32C031_v1r0:     Official release
		=======================================================
		First release: adding support to STM32C031 devices.
		=======================================================
		STM32C031_v1r1:     Official release
		=======================================================
		Adding suuport for Flash registers
		=======================================================
		STM32C031_v1r2:     Official release
		=======================================================
		updating interrupts for C011/C031
		
		=======================================================
		STM32C011_v1r0:     Official release
		=======================================================
		First release: adding support to STM32C011 devices.
		=======================================================
		STM32C011_v1r1:     Official release
		=======================================================
		Adding suuport for Flash registers
		=======================================================
		STM32C011_v1r2:     Official release
		=======================================================
		updating interrupts for C011/C031
		