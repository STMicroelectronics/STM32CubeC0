**
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32C07x devices support on EWARM.
  ************************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************

 Package general purpose:
  ======================================================================================================================	
    These packages contains the needed files to be installed in order to support STM32C07x devices by EWARM9 and laters.

    We inform you that this package is suitable for internal & external use.
	EWARMv9_STM32C07x_V1.0.1.exe has been digitally signed by STMicroelectronics.

  By running the "Install_Patch.bat" file (as an administrator), the following actions will be performed: : 
  ================================================================ 
     1. If you have previously installed an STM32 patch, it will be removed during the first run. 
     2. The following items will be added :
      
	  - Part Numbers with 128KB Flash size: STM32C071xB.
      - Part Numbers with 64KB Flash size: STM32C071x8.
      
	  - Automatic STM32C0xx flash algorithm selection
	  
     3. The following SVD files will be added: 
	  - STM32C071 SVD files v1r2. 


PS: That you can run EWARMv9_STM32C07x_V1.0.1.exe only if the uninstall is not needed.
	
  How to use:
  ==========
  * Before installing the files mentioned above, you need to have EWARM v9.xx or later installed. 
   
    You can download EWARM from IAR web site @ www.iar.com

  * Run "EWARMv9_STM32C07x_V1.0.1.exe" as administrator at EWARM install directory.
    EWARM Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \",

  SVD files ReleaseNotes:
  =======================
	=======================================================
	STM32C0_v1r4:     initial release
	=======================================================
	V1.0   First release: adding support to STM32C0 devices (32K)
	V1.1   Adding suuport for Flash registers
	V1.2   Adding support for STM32C071 and updating interrupts for C011/C031
	V1.3   Adding support for STM32C051/C091 and C092.
	V1.4   Update in Flash description for STM32C0 devices

	



