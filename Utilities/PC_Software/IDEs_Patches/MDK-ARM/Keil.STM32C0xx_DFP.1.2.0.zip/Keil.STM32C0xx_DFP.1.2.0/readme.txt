 /**
  ******************************************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32C0xx devices support on MDK-ARM.
  ******************************************************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *****************************************************************************************************************************/

  Package general purpose:
  ===============================================================================================================================
	These packages contains the needed files to be installed in order to support STM32C0xx devices by MDK-ARM v5.25 and laters.

	We inform you that this package is suitable for internal & external use.
  
  Running the "Keil.STM32C0xx_DFP.1.2.0.pack" adds the following: 
  ================================================================================================================================ 
	1. Part numbers for  :
		- Product lines with 256KB Flash size: STM32C091xCxx, STM32C092xCxx.
		- Product lines with 128KB Flash size: STM32C071xBxx, STM32C091xBxx, STM32C092xBxx.
		- Product lines with 64KB Flash size: STM32C071x8xx, STM32C051x8xx.
		- Product lines with 32KB Flash size: STM32C011x6xx, STM32C031x6xx, STM32C051x6xx.
		- Product lines with 16KB Flash size: STM32C011x4xx, STM32C031x4xx. 
		
		- Automatic STM32C0xx flash algorithm selection
		
	2. The following SVD files will be added:
		- STM32C071 SVD files v1r1.
		- STM32C031 SVD files v1r2.
		- STM32C011 SVD files v1r2.
		- STM32C051 SVD files v1r0.
		- STM32C091 & STM32C092  SVD files v1r0.

 How to use:
 =================================================================================================================================
	* Before installing the files mentioned above, you need to have MDK-ARM v5.25 
	  or later installed. 
	  You can download pack from keil web site @ www.keil.com
 
	* Double Clic on  "Keil.STM32C0xx_DFP.1.2.0.pack" in order to install this pack in 
	  the Keil install directory.
	
	PS: Please make sure that you are using PackUnzip.exe to run this pack.
 
 
 SVD files ReleaseNotes:
 ==================================================================================================================================
    
	==================================================================================================================================
    STM32C0_V1.0   First release: adding support to STM32C0 devices (32K)
    STM32C0_V1.1   Adding suuport for Flash registers
	STM32C0_V1.2   Adding support for STM32C071 and updating interrupts for C011/C031
	STM32C0_V1.3   Adding support for STM32C051/C091 and C092.
    ==================================================================================================================================



      






	



