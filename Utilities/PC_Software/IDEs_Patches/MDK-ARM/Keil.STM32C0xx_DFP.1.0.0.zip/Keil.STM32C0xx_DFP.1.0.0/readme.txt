/**
  ***************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32U5xx devices support on MDK-ARM.
  ***************************************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************
  These packages contains the needed files to be installed in order to support STM32C01x-03x 
  devices by MDK-ARM v5.25 and laters.

  Running the "Keil.STM32C0xx_DFP.1.0.0.pack" adds the following:
  ==============================================================
   - Part Numbers with 32KB Flash size: STM32C011x6/STM32C031x6
   - Part Numbers with 16KB Flash size: STM32C011x4/STM32C031x4
   - Automatic STM32C0xx flash algorithm selection
   - STM32C011 and STM32C031 SVD files


  How to use:
  ==========
  * Before installing the files mentioned above, you need to have MDK-ARM v5.25 or later installed. 
  You can download pack from keil web site @ www.keil.com
 
  * Double Clic on  "Keil.STM32C0xx_DFP.1.0.0.pack" in order to install this pack in the Keil install 
  directory.

