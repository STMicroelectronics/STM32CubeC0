 /**
  ******************************************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32C0xx devices support on MDK-ARM.
  ******************************************************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *****************************************************************************************************************************/

  Package general purpose:
  ===============================================================================================================================
	These packages contains the needed files to be installed in order to support STM32C0xx devices by MDK-ARM v5.25 and laters.

	We inform you that this package is suitable for internal use only.
  
  Running the "Keil.STM32C0xx_DFP.1.1.0.pack" adds the following: 
  ================================================================================================================================ 
	1. Part numbers for  :
		- Product lines with 128KB Flash size: STM32C071xB 
		- Product lines with 64KB Flash size: STM32C071x8 
		- Product lines with 32KB Flash size: STM32C011x6/C031x6  
		- Product lines with 16KB Flash size: STM32C011x4/C031x4 
		
		- Automatic STM32C0xx flash algorithm selection
		
	2. The following SVD files will be added:
		- STM32C071 SVD files v1r1.
		- STM32C031 SVD files v1r1.
		- STM32C011 SVD files v1r1.

 How to use:
 =================================================================================================================================
	* Before installing the files mentioned above, you need to have MDK-ARM v5.25 
	  or later installed. 
	  You can download pack from keil web site @ www.keil.com
 
	* Double Clic on  "Keil.STM32C0xx_DFP.1.1.0.pack" in order to install this pack in 
	  the Keil install directory.
	
	PS: Please make sure that you are using PackUnzip.exe to run this pack.
 
 
 SVD files ReleaseNotes:
 ==================================================================================================================================
	=======================================================
    STM32C071_v0r1:     initial release
    =======================================================
    Doc ID: RM0490 - Rev 3.1c - 28 June 2023
    
    IPs Derived from IPxact (ipxact_RM0490_V3_STM32C0_Spider_1230908_1432):
    - Complete support for interrupts
    - Reducing warnings number by 100% (0 Errors and 0 Warnings)
    - Only missing TIM2 & USBSRAM
    
    =======================================================
    STM32C071_v1r0:     official release
    =======================================================
    Doc ID: RM0490 - Rev 3.1c - 28 June 2023
    
    Update version for official release 0.1 => 1.0
    
    #update license section#
    
    =======================================================
    STM32C071_v1r1:     update
    =======================================================
    Doc ID: RM0490 Rev 3.2
    
    update to be aligned with latest RM
    adding support for missing IPs (TIM2)
    complete support for interrupts
    0 ERRORS/0 WARNINGS
	
    =======================================================
    STM32C011_V1.0   First release: adding support to STM32C0 devices (32K)
    STM32C011_V1.1   Adding suuport for Flash registers
    =======================================================
	
	=======================================================
    STM32C031_V1.0   First release: adding support to STM32C0 devices (32K)
    STM32C031_V1.1   Adding suuport for Flash registers
    =======================================================








      






	



